<?php
/**
 * 0 style - when no style is selected
 * Hide on Desktop or Hide on Mobile
 */